-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2018 at 05:36 AM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reg`
--

-- --------------------------------------------------------

--
-- Table structure for table `reg_table`
--

CREATE TABLE `reg_table` (
  `ID` int(10) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `mail` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `skills` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `zip` int(20) NOT NULL,
  `cv` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reg_table`
--

INSERT INTO `reg_table` (`ID`, `fname`, `lname`, `mail`, `gender`, `dob`, `skills`, `address`, `zip`, `cv`) VALUES
(1, 'Rupali', 'Chaughule', 'roop4894@gmail.com', 'female', '1994-08-04T20:00', 'HTML,CSS,PHP', 'Bhiwandi\r\nThane', 421302, '5steps.pdf'),
(2, 'Rupali', 'Chaughule', 'roop4894@gmail.com', 'female', '1994-08-04T20:00', 'HTML,CSS,PHP', 'Bhiwandi\r\nThane', 421302, '5steps.pdf'),
(3, 'bhargavi', 'Rane', 'bha@gmail.com', 'female', '1997-08-04T16:00', 'html,css', 'Thane', 421302, 'my edit.php'),
(4, 'Harsh', 'Patil', 'harsh@gmail.com', 'male', '2000-11-05T13:00', 'HTML,CSS,PHP', 'Pune', 456333, 'registration.sql'),
(5, 'arya', 'Manas', 'arya@gmail.com', 'female', '1998-05-08T02:03', 'HTML', 'Nagpur', 421302, 'practice.php'),
(6, 'Pooja', 'Verma', 'pooja@gmail.com', 'female', '1994-04-02T16:00', 'HTML,CSS,PHP', 'Airoli', 421302, '3.jpg'),
(7, 'Poonam', 'Konde', 'poonam@gmail.com', 'female', '1994-02-04T15:00', 'HTML,CSS,PHP', 'Thane', 436455, 'select.php');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reg_table`
--
ALTER TABLE `reg_table`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reg_table`
--
ALTER TABLE `reg_table`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
