<?php
include('connect.php');
error_reporting(0);
session_start();

if(isset($_POST['login'])){
	
	$mail = $_POST['mail'];
	$fname = $_POST['fname'];
	
	$login = mysqli_query($conn, "select * from reg_table where mail='".$mail."' AND fname='".$fname."'");
	$user_data = mysqli_fetch_array($login);
	$no = mysqli_num_rows($login);
	
	if($no == 1){
		
		$_SESSION['id'] = $user_data['ID']; 
		
		if(isset($_POST['remember']) && $_POST['remember'] == 1){
			setcookie("uname", $mail, time()+(60*60*24));
			setcookie("upass", $fname, time()+(60*60*24));
		}
		else{
			setcookie("Details", "PHP");
		}		
		
		
		echo "<script>window.alert('login Successfully')</script>";
		echo "<script>window.location.href='profile.php'</script>";
	}
	else{
		echo "<script>window.alert('Please check your username or password')</script>";
	}

}






?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registration Form</title>
</head>

<body>
<center>
<h3>Login Form</h3>
<form method="post">
<table>

<tr>
<th>Email:</th>
<td><input type="email" name="mail" value="<?php echo $_COOKIE['uname']; ?>"/></td></tr>
<tr>
<th>Password:</th>
<td><input type="password" name="fname" value="<?php echo $_COOKIE['upass']; ?>" /></td></tr>
<tr>

<td colspan="2" align="center"><input type="checkbox" name="remember" value="1"
<?php if(isset($_COOKIE['uname'])){ echo "checked='checked'";}?>

 /><label>Remember Me?</label></td></tr>

<tr align="center">
<td colspan="2" >
<input type="submit" name="login" value="Login" />

</td></tr>
</table>
</form>
</center>
</body>
</html>