<?php
session_start();
if(!isset($_SESSION['id'])){
	header('location:index1.php');
}
include('connect.php');
$id = $_SESSION['id'];
$sel_user = mysqli_query($conn, "select * from reg_table where ID='".$id."'");
$data = mysqli_fetch_array($sel_user);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Profile</title>
</head>

<body>
Welcome <?php echo $data['fname']; ?><a href="logout1.php" style="float:right;">Logout</a>
<table>
<tr>
<th>Name</th>
<td><?php echo $data['fname']; ?></td>
</tr>
<tr>
<th>Email</th>
<td><?php echo $data['mail']; ?></td>
</tr>
</table>


</body>
</html>