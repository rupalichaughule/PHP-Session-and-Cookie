<?php
include('connect.php');
 
session_start();

if(isset($_POST['login'])){
	
	$mail = $_POST['mail'];
	$fname= $_POST['fname'];
	
	$login = mysqli_query($conn, "select * from reg_table where mail='".$mail."' AND fname='".$fname."'");
	$user_data = mysqli_fetch_array($login);
	$no = mysqli_num_rows($login);
	
	if($no == 1){
		
		$_SESSION['id'] = $user_data['ID']; 
		
		echo "<script>window.alert('login Successfully')</script>";
		echo "<script>window.location.href='profile1.php'</script>";
	}
	else{
		echo "<script>window.alert('Please check your username or password')</script>";
	}

}






?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registration Form</title>
</head>

<body>
<center>
<h3>Login Form</h3>
<form method="post">
<table>

<tr>
<th>Email:</th>
<td><input type="email" name="mail" /></td></tr>
<tr>
<th>Password:</th>
<td><input type="text" name="fname" /></td></tr>

<tr align="center">
<td colspan="2" >
<input type="submit" name="login" value="Login" />

</td></tr>
</table>
</form>
</center>
</body>
</html>